package college.placement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlacementProjectTnsApplication1Application {

	public static void main(String[] args) {
		SpringApplication.run(PlacementProjectTnsApplication1Application.class, args);
	}
}
