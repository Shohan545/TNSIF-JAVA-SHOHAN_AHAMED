package placementproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShajanehswarPlacementProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShajanehswarPlacementProjectApplication.class, args);
	}

}
